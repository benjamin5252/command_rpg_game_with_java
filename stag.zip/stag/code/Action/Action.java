package Action;

import java.util.ArrayList;

public class Action {
    public ArrayList<String> triggers = new ArrayList<String>();
    public ArrayList<String> subjects = new ArrayList<String>();
    public ArrayList<String> consumed = new ArrayList<String>();
    public ArrayList<String> produced = new ArrayList<String>();
    public String narration;
}

