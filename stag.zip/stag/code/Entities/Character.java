package Entities;

public class Character extends Entity {
    public String entityType = "Entities.Character";
}
