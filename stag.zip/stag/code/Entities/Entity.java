package Entities;

public class Entity {
    public String id;
    public String description;
}
