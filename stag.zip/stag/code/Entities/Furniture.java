package Entities;

public class Furniture extends Entity {
    public String entityType = "Entities.Furniture";
}
